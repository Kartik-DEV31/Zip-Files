import java.util.*;


						class problem9{

									public static void main(String[] args) {
										
											Scanner a= new Scanner(System.in);
											System.out.print("Enter the starting number : ");
											int num1=a.nextInt(); 

											Scanner b= new Scanner(System.in);
											System.out.print("Enter the Ending number : ");
											int num2=b.nextInt();	
											
											System.out.print("Youre answer is : ");


											for (int i = num1;i<=num2;i++)
												System.out.print(i+" ");




									}




						}