import java.util.Scanner;

public class JavaAssignment3 {

	public static void main(String[] args) {
		
		
		Scanner num = new Scanner(System.in);
		System.out.print("Enter an Integer : - ");
		int D = num.nextInt() ;
		
		
			
		
          String s =  	D%2==0 ? "Number is Even" : "Number is Odd" ; 
			System.out.println(s);
		
		
			
	}

}
